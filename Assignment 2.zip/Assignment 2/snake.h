#ifndef SNAKE_H
#define SNAKE_H

void moveSnake(char*** mapArray, char** player,  int playerRowLoc, int playerColLoc, int* snakeRowLoc, int* snakeColLoc, int* bit);

#endif